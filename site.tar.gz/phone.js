'use strict';
const appFrame=document.querySelector('#app-preview');
appFrame.addEventListener('load',()=>{
  // Both documents share the Site origin. Retain existing public hash links.
  appFrame.contentWindow.addEventListener('hashchange',()=>{
    const next=appFrame.contentWindow.location.hash;
    if(location.hash!==next)history.replaceState(null,'',location.pathname+location.search+next);
  });
});
appFrame.src='app.html'+location.hash;
window.addEventListener('hashchange',()=>{
  if(appFrame.contentWindow.location.hash!==location.hash)appFrame.contentWindow.location.hash=location.hash;
});
